var count = 1;
var passengers;
var pass_arr = [[]];
var pass1 = [];
function verify(){​​​​​​
    var  usr = document.getElementById("usr").value;
    var  pass = document.getElementById("pass").value;
    if(usr == "admin" && pass == "admin123"){​​​​​​
        document.getElementById("box").style.display = "none";
        document.getElementById("train-reg").style.display = "contents";
    }​​​​​​
    else
        alert(usr+" Login Failed....")
    }​​​​​​
function addPassengers(){​​​​​​
    document.getElementById("pass-btn").style.display="none";
    passengers = parseInt(document.getElementById("passengers").value);
    var text = "<h2>Add Passengers details<h2><br>";
    text += "<div id='text-div'><h3>Passenger "+ count +"</h3><br><b>Name</b> : <input type='text' name='name' id='pass-name' required><br><b>Age</b> : <input type='number' name='age' id='pass-age'><br><b>Gender</b> : Male <input type='radio' name='gender' value='M'> Female <input type='radio' name='gender' value='F'><br>"
    // if(count++ < passengers)
        text += "<button onclick='add()'>Add</button></div>"
    document.getElementById("pass-count").innerHTML = text;
    console.log(pass_arr)
}​​​​​​
function add(){​​​​​​
    let name = document.getElementById("pass-name").value
    let age = document.getElementById("pass-age").value
    let gender = document.getElementsByName("gender")
    let gen;
    if(gender[0].checked)
        gen = gender[0].value
    else if(gender[0].checked)
        gen = gender[1].value
    console.log(name+" "+age+" "+gender+" "+gen+" "+pass1)
    pass1 = pass1.concat([name,age,gen]);
    console.log(pass1)
    //pass_arr.push(pass1);
    console.log(pass_arr)
    if(count++ < passengers)
        addPassengers();
    else 
        document.getElementById("text-div").innerHTML = "<h1> All Passengers detail stored succesfully<br><button type='submit' onclick='printdetail()''>print details</button></h1>"   
    }​​​​​​
    console.log(pass_arr);
    function printdetail(){​​​​​​
        let xc = pass1.length;
        var txt = "<table style='width:100%'<tr>    <th>name</th>    <th>age</th>        <th>gender</th> "
        for(let i=0;i<xc;i=i+3){​​​​​​
            txt += "<tr><td>"+pass1[i]+"</td><td>"+pass1[i+1]+"</td><td>"+pass1[i+2]+"</td></tr>"
        }​​​​​​
        txt += "</table>"
        document.getElementById("text-div").innerHTML = txt;
    }​​​​​​