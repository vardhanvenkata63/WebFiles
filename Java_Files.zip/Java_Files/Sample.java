import java.util.*;
public class Sample{
    public static void main(String args[]){
        System.out.println("Hello WOrld");
        Scanner scr = new Scanner(System.in);
        String name=scr.next();
        System.out.println("Hello "+name+" welcome to Java");

    }
}