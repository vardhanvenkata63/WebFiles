function findtrain(){
    var tno=parseInt(document.getElementById("trainno").value);
    if(tno!=0){
        console.log("Train Exist");
    }
    else{
        console.log("Train Doesn't Exist");
    }
}
function passengersdetails(){
    var pcount=parseInt(document.getElementById("pcount").value);
    var text="";
    for(var i=1;i<=pcount;i++){
        text+="<h2>Add Passenger "+i+"<div><label>Enter Passenger Name</label><br></br><input type='text' id='pname"+i+"'/><br/><label for='page'>Enter Age</label><br/><input type='text' id='page"+i+"'><br/><label for='pgender'>Enter Gender(M/F)</label><br><input type='text' id='pgender"+i+"'><br><input type='submit' value='add' onclick='addPassenger()'></div>";
         
    }
    document.getElementById("p1").innerHTML=text;
}
function addPassenger(){
    var pdetails=[];
    for(var i=1;i<=pcount;i++){
    var pname="pname"+i;
    var page="page"+i;
    var pgender="pgender"+i;
    var pname1=document.getElementById(pname).value;
    var page1=document.getElementById(page).value;
    var pgender1=document.getElementById(pgender).value;
    console.log(pname1+" "+page1+" "+pgender1);
    pdetails=[pname1,page1,pgender1];
    pdetails.push([pname1,page1,pgender1]); 
    } 
    console.log(pdetails);
}