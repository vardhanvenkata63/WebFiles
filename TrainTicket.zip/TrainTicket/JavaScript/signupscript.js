function verify(){
    var fullname=document.getElementById("fullname").value;
    var username=document.getElementById("username").value;
    var phoneno=document.getElementById("phoneno").value;
    var email=document.getElementById("email").value;
    var pwd1=document.getElementById("pwd1").value;
    var pwd2=document.getElementById("pwd2").value;
    if(fullname.length!=0 && username.length
    !=0 && phoneno.length!=0 && email.length!=0 && pwd1==pwd2){
        alert("Signup Successful");
    }
    else if(pwd1!=pwd2){
        alert("Passwords should match");
    }
    else{
        alert("Signup not Successful enter details correclty")
    }
}