function validate(){
    var username=document.getElementById("uname").value;
    var pwd=document.getElementById("pwd").value;
    if(username==="admin" && pwd==="admin123"){
        alert("Valid User");
        var text="<a href='../Html Files/Details.html'/>";
        document.getElementById("p1").innerHTML=text;
    }
    else{
        alert("Invalid User");
    }
}