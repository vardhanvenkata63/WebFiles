function percentageCheck(){
    var per=parseInt(document.getElementById("percentage").value);
    if(per>=80 && per<=100){
        alert("A Grade")
    }
    else if(per>=70 && per<80){
        alert("B Grade")
    }
    else if(per>=60 && per<70){
        alert("C Grade")
    }
    else if(per>=50 && per<60){
        alert("D Grade")
    }
    else if(per>=0 && per<50){
        alert("Fail")
    }
    else{
        alert("Enter percentage between 0 and 100")
    }
}
function day(){
    var day=parseInt(document.getElementById("day").value);
    switch(day){
        case 1:alert("Monday");
                break;
        case 2:alert("Tuesday");
                break;
        case 3:alert("Wednesday");
                break;
        case 4:alert("Thursday");
                break;
        case 5:alert("Friday");
                break;
        case 6:alert("Saturday");
                break;
        case 7:alert("Sunday");
                break;
    }
    }