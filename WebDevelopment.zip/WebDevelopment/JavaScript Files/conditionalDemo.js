function checkAge(){
    var age=parseInt(document.getElementById("age").value);
    if(age<18){
        alert("Not Eligible for Voting")
    }
    else{
        alert("Eligible for Voting")
    }
}